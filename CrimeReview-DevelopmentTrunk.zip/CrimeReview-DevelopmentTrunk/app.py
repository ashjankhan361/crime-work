from flask import Flask,request,render_template
app = Flask(__name__)

@app.route("/")
def home():
    return render_template('/formsearch_exptflask.html')

@app.route("/form-validation/")
def validation():
    return render_template('formvalidationflask.html')

@app.route("/form-search/")
def search():
    return render_template('formsearchflask.html')

@app.route("/form-search_expt/")
def search_expt():
    return render_template('formsearch_exptflask.html')

@app.route("/form-register/")
def register():
    return render_template('formregisterflask.html')

@app.route("/form-mini/")
def mini():
    return render_template('formminiflask.html')

@app.route("/form-login/")
def login():
    return render_template('formloginflask.html')

@app.route("/Admins-Form/")
def adminsForm():
    return render_template('adminformflask.html')


app.route('/api/data')
def get_data():
  return app.send_static_file('data.json')